from .model.FinancialSymbolsSource import FinancialSymbolsRegistry


def _perform_search(term: str, fin_syms_registry: FinancialSymbolsRegistry):
    # print(term)
    print(term)
