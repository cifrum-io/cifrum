import os

_MONTHS_PER_YEAR = 12

rostsber_url = os.environ.get('ROSTSBER_URL', 'http://rostsber.ru/api/data/')
change_column_name = 'close_pctchange'
