import yapo
import pandas as pd
import numpy as np

from yapo.model.TimeSeries import TimeSeries


def test():
    portfolio = yapo.portfolio(assets={'nlu/922': 0.4,
                                       'micex/FXRU': 0.4,
                                       'micex/FXMM': 0.2},
                               start_period='2016-09', end_period='2017-12', currency='RUB')
    ror = portfolio.rate_of_return()[:20]
    expected = TimeSeries(
        start_period=pd.Period('2016-10', freq='M'),
        end_period=pd.Period('2017-12', freq='M'),
        derivative=1, values=np.array([
            0.00791244, 0.02163977, 0.00804284, 0.00157041, -0.04348766,
            -0.01533009, 0.01497332, -0.01507169, 0.01663497, 0.03062482,
            0.0112141, 0.00886217, 0.00376491, 0.01234183, 0.00042616
        ])
    )
    v = ror - expected
    print(np.all(v.values < 1e-6))

    # asset = yapo.portfolio_asset(name='nlu/449', start_period='2015-4', end_period='2015-6', currency='USD')
    # asset = yapo.portfolio_asset(name='micex/SBER', start_period='2010-4', end_period='2016-2')
    # asset = yapo.portfolio_asset(name='quandl/MSFT', start_period='2010-4', end_period='2016-2')

    # yapo.efficent_frontier(kind='???', assets=['quandl/BND', 'quandl/VTI', 'quandl/VXUS'], samples=10)
    # yapo.correlation_matrix(assets=['quandl/BND', 'quandl/VTI', 'quandl/VXUS'])

    prtflio = yapo.portfolio(assets={'quandl/BND': .4, 'quandl/VTI': .4, 'quandl/VXUS': .2},
                             currency='usd',
                             start_period='2018-1', end_period='2018-6')
    print(prtflio.assets[0].compound_annual_growth_rate(years_ago=None, real=True))

    asset = yapo.portfolio_asset(name='micex/GAZP')
    cagr = asset.compound_annual_growth_rate(real=True, years_ago=2)
    aror = asset.accumulated_rate_of_return(real=True)

    prtflio = yapo.portfolio(assets={'quandl/BND': .4, 'quandl/VTI': .4, 'quandl/VXUS': .2},
                             start_period='2016-6', end_period='2016-12', currency='usd')
    infl1 = prtflio.inflation(kind='accumulated')
    infl2 = prtflio.inflation(kind='mean')
    infl3 = prtflio.inflation(kind='values')

    print('hi')


if __name__ == '__main__':
    test()
