import yapo
from model.Enums import Currency
import numpy as np
import model.Settings as Settings

Settings.return_raw_numpy = True

if __name__ == '__main__':
    # all_symbols = ['quandl/MSFT',
    #                'micex/SBER', 'micex/SBERP', 'micex/MCFTR',
    #                'nlu/419',
    #                'cbr/USD', 'cbr/EUR', 'cbr/RUB',
    #                'cbr/TOP_rates',
    #                'infl/RUB', 'infl/EUR', 'infl/USD']
    # for sym in all_symbols:
    #     syms = yapo.information(name=sym)
    #     vs = syms.values(start_period='2015-1', end_period='2017-6')
    #     print(sym)

    portfolio = yapo.portfolio(assets={'nlu/922': 0.4,
                                       'micex/FXRU': 0.4,
                                       'micex/FXMM': 0.2},
                               start_period='2016-09', end_period='2017-12', currency='RUB')
    v = portfolio.accumulated_rate_of_return()
    print(v)
    v = portfolio.accumulated_rate_of_return(real=True)
    print(v)
    v = portfolio.accumulated_rate_of_return(real=False)
    print(v)

    p = yapo.portfolio(assets={'nlu/449': .5, 'micex/SBER': .5},
                       start_period='2015-1', end_period='2015-6', currency='USD')
    ror = p.rate_of_return()
    assert ror.shape == (7, 1)

    # asset = yapo.portfolio_asset(name='nlu/449', start_period='2015-4', end_period='2015-6', currency='USD')
    # asset = yapo.portfolio_asset(name='micex/SBER', start_period='2010-4', end_period='2016-2')
    # asset = yapo.portfolio_asset(name='quandl/MSFT', start_period='2010-4', end_period='2016-2')

    pass

    # yapo.efficent_frontier(kind='???', assets=['quandl/BND', 'quandl/VTI', 'quandl/VXUS'], samples=10)
    # yapo.correlation_matrix(assets=['quandl/BND', 'quandl/VTI', 'quandl/VXUS'])

    prtflio = yapo.portfolio(assets={'quandl/BND': .4, 'quandl/VTI': .4, 'quandl/VXUS': .2},
                             currency='usd',
                             start_period='2018-1')
    print(prtflio.assets[0].compound_annual_growth_rate(years_ago=None, real=True))

    asset = yapo.portfolio_asset(name='micex/GAZP')
    cagr = asset.compound_annual_growth_rate(real=True, years_ago=2)
    aror = asset.accumulated_rate_of_return(real=True)

    prtflio = yapo.portfolio(assets={'quandl/BND': .4, 'quandl/VTI': .4, 'quandl/VXUS': .2},
                             start_period='2016-6', end_period='2016-12', currency='usd')
    infl1 = prtflio.inflation(kind='accumulated')
    infl2 = prtflio.inflation(kind='mean')
    infl3 = prtflio.inflation(kind='values')

    print('hi')

