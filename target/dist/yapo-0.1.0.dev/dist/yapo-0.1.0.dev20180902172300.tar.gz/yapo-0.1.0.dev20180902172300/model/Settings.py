import os

rostsber_url = os.environ.get('ROSTSBER_URL', 'http://rostsber.ru/api/data/')
change_column_name = 'close_pctchange'

return_raw_numpy = True
